﻿namespace WildFarm.Models.Food
{
    public class Seeds : Food
    {
        public Seeds(int foodQuantity) : base(foodQuantity) { }
    }
}