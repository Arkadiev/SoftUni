﻿namespace Vehicles
{
    public interface IDriveable
    {
        void Drive(double distance);
    }
}