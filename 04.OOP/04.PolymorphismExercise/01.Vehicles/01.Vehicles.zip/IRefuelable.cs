﻿namespace Vehicles
{
    public interface IRefuelable
    {
        void Refuel(double amount);
    }
}