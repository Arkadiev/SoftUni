﻿namespace FoodShortage
{
    public interface IIdentifiable
    {
        string Id { get; }

        string Birthdate { get; }
    }
}