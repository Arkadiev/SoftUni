﻿namespace Telephony
{
    public interface ICaller
    {
        void Call(string number);
    }
}