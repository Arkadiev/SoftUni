﻿namespace Telephony
{
    public interface IBrowser
    {
        void Browse(string url);
    }
}