﻿namespace CommandPattern.Core.Contracts
{
    public interface IEngine
    {
        public void Run();
    }
}