﻿namespace NauticalCatchChallenge.Repositories.Contracts
{
    public interface IRepository
    {
    }
}