﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-M3E5HH3\SQLEXPRESS; Database=MusicHub; Integrated Security=True";
    }
}