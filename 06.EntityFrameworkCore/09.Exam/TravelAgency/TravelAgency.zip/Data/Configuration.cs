﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelAgency.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-M3E5HH3\SQLEXPRESS;Database=TravelAgency;Integrated Security=True;Encrypt=False";
    }
}