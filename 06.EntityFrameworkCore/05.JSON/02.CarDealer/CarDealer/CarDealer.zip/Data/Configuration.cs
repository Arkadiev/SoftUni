﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-M3E5HH3\SQLEXPRESS; Database=CarDealer; Integrated Security=True; Encrypt=False";
    }
}