﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-M3E5HH3\SQLEXPRESS;Database=Invoices2024;Integrated Security=True;Encrypt=False";
    }
}