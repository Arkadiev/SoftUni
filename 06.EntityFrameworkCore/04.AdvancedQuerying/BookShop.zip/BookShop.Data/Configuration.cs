﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=DESKTOP-M3E5HH3\\SQLEXPRESS; Database=BookShop; Integrated Security=True;";
    }
}