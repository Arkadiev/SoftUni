﻿namespace GenericScale
{
    internal class StartUp
    {
        static void Main(string[] args)
        {
            // Nothing to see here
        }
    }
}