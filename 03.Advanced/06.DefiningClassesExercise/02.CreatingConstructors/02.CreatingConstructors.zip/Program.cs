﻿namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            // Nothing to see here
        }
    }
}